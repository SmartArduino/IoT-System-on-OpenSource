#ifndef GLOBAL_H
#define	GLOBAL_H

unsigned long osEnterSum=0;

#endif
