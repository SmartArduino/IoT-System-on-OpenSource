#ifndef _USER_H_
#define _USER_H_

#define procIdA 1
#define procIdB	2

#include <stdio.h>
#include "portable.h"

void user_process_a(void);
void user_process_b(void);
void user_process_init(void);

#endif
