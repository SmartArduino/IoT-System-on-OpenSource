#ifndef _STRING_H_
#define _STRING_H_

void string_copy(char *pDest, char *pSrc, int len);
int string_length(char *pStr);
int string_compare(char *pSrc, char *pDst);

#endif
