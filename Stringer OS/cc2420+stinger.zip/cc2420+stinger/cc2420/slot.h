#ifndef _SLOT_H_
#define _SLOT_H_

void slot_test_a(int x);
void slot_test_b(int x);
void slot_add(int x, int y, int z);

#endif
