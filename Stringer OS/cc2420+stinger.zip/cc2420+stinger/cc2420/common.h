#ifndef _COMMON_H_
#define _COMMON_H_

void delay(int ns);

#endif
