#ifndef _POWER_H_
#define _POWER_H_

#include <stdio.h>

#endif
